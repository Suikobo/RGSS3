﻿<!--
$(function () {

// ロード時モジュールセットアップ
setupModules();

// モジュール追加
$("#add").click(function() {
  var module = window.prompt("追加するモジュールを入力して下さい。");
  if (module != "" && module != null) {
    saveCookie(module);
  }
  setupModules();
});

// モジュール削除
$("#del").click(function() {
  var module = window.prompt("削除するモジュールを入力して下さい。");
  if (module != "" && module != null) {
    removeCookie(module);
  }
  setupModules();
});

// モジュールの説明
$("#help").click(function() {
  var text = "メニュー内に追加モジュールを表示するには、\n「modules」フォルダに追加モジュールのドキュメントをコピーし、\n「add」ボタンでフォルダ名を入力して下さい。";
  text += "\n\n※クッキーを使用しているので、クッキーを削除したりブラウザを変えた場合は再設定が必要です。";
  text += "\nなお、オンライン版では管理人がサーバーにアップしたもののみ追加可能です。";
  alert(text);
});

// クッキーの読込
function loadCookie() {
  if (!$.cookie("tes_modules")) return new Array();
  return $.cookie("tes_modules").split('\t');
};

// クッキーへの保存
function saveCookie(module) {
  var modules = loadCookie();
  var text = "";
  if ($.inArray(module, modules) == -1) {
    text = modules.join('\t');
    text += '\t' + module;
    $.cookie("tes_modules", text);
  }
};

// クッキーからの削除
function removeCookie(module) {
  var modules = loadCookie();
  var text = "";
  var index = $.inArray(module, modules)
  if (index != -1) {
    modules.splice(index, 1);
    text = modules.join('\t');
    $.cookie("tes_modules", text);
  }
};

function setupModules() {
  var modules = loadCookie();
  $("#modules").text("");
  if (modules.length == 0) return;
  for (var i = 0; i < modules.length; i++) {
    $.get("./modules/" + modules[i] + "/menu_" + modules[i] + ".html", function (data) {
    if (window.location.href.split('/').pop() == "menu_type1.html") {
      data = data.replace(/<ul>[\s\S]+<\/ul>/, "");
    }
    $("#modules").append(data);
    }, "html");
  }
};

});
 
// -->